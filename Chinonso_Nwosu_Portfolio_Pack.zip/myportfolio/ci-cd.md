# CI/CD (GitHub Actions)

This portfolio includes automation projects executed via GitHub Actions CI.

## What CI Does
- Runs tests on push/PR
- Produces artifacts (screenshots/videos) on failures
- Optional scheduled runs

Add a screenshot of a green build to `assets/images/` and link it here:
- [View CI Evidence](assets/images/ci-green-build.png)
