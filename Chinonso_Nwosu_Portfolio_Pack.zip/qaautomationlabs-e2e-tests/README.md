# qaautomationlabs-e2e-tests

E2E UI automation for the demo e-commerce application: https://shop.qaautomationlabs.com/

## Tech Stack
- Cypress (JavaScript)
- GitHub Actions (CI)

## Test Coverage
- Login (valid/invalid)
- Add to cart / remove from cart
- Update cart quantity
- Checkout (happy path + validations)
- Basic UI assertions for critical elements

## Project Structure (recommended)
```
cypress/
  e2e/
    login.cy.js
    cart.cy.js
    checkout.cy.js
  fixtures/
    testData.json
  support/
.github/
  workflows/
    ci.yml
cypress.config.js
package.json
README.md
```

## How to Run Locally
1. Install dependencies:
   - `npm ci`
2. Run in headed mode:
   - `npx cypress open`
3. Run headless:
   - `npx cypress run`

## Environment Variables
Set these in GitHub Actions (Repo → Settings → Secrets and variables → Actions):
- `CYPRESS_baseUrl` = `https://shop.qaautomationlabs.com/`

(If you use credentials, store them as secrets too.)

## CI (GitHub Actions)
- Runs on push and pull requests
- Uploads screenshots/videos as artifacts on failure

See: `.github/workflows/ci.yml`

## Notes for CI-Safe Tests
- Avoid brittle selectors (prefer data-* attributes when available)
- Add stable waits only when necessary; prefer waiting for UI state
- Keep assertions focused on business outcomes (cart count, totals, navigation)
